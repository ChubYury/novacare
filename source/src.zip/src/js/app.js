import * as flsFunctions from "./modules/webpTest.js"
import { 
  showMenu,
  hiddenMenu } from "./modules/buttons.js";

document.addEventListener('DOMContentLoaded', () => {
  flsFunctions.isWebp();
  
  //--- My modules ------
  showMenu();
  hiddenMenu();
})
