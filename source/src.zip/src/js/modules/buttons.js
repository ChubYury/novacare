export function showMenu () {
  const htmlBody = document.body;
  const [menuBtn] = document.getElementsByClassName('js-btn-menu');
  const [menuContent] = document.getElementsByClassName('js-menu-content');
  const menuNav = menuContent.firstChild.nextSibling;
  
  menuBtn.addEventListener('click', e => {
    e.preventDefault();
    
    htmlBody.classList.toggle('not-scroll');
    menuBtn.classList.toggle('is-active');
    menuContent.classList.toggle('is-active');
    menuNav.classList.toggle('is-active');
  });
};

export function hiddenMenu() {
  const htmlBody = document.body;
  const [menuBtn] = document.getElementsByClassName('js-btn-menu');
  const [menuContent] = document.getElementsByClassName('js-menu-content');
  const menuNav = menuContent.firstChild.nextSibling;
  const linkList = [...menuNav.children];
  
  console.log(linkList);
  
  linkList.forEach(el => {
    el.addEventListener('click', e => {
      // e.preventDefault();

      htmlBody.classList.remove('not-scroll');
      menuBtn.classList.remove('is-active');
      menuContent.classList.remove('is-active');
      menuNav.classList.remove('is-active');
    });
  });
};